#include <stdio.h>
#include <stdlib.h>

/*모든 환경 변수를 출력한다.*/
int main(int argc, char *argv[])// **argv나 *argvi[] 차이점
{
  char **ptr;
  extern char **environ;
//extern : 내 파일이 아니라 다른 파일에 정의 되어져있는 변수를 쓰려고 할때 , 외부 변수를 쓰려 할때 사용
  for(ptr = environ; *ptr != 0; ptr++) /*모든 환경 변수 값 출력*/
    printf("%s\n", *ptr);

  exit(0);
}
