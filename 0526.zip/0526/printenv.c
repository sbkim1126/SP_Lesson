#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

int main()
{
  char *ptr;

  ptr = getenv("HOME");
  printf("HOME = %s\n", ptr);

  ptr = getenv("SHELL");
  printf("SHELL = %s\n", ptr);

  ptr = getenv("PATH");
  printf("PATH = %s\n", ptr);

  //exit(0);
  //abort();
  //exit(7);
  //_exit(7); => unistd.h를 선언하니까 warning이 안뜸
  //_exit(6);
  
}
