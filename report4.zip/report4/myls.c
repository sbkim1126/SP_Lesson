#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<fcntl.h>
#include<dirent.h>
#include<sys/stat.h>
#include<unistd.h>

//해당 파일의 인노드 번호를 저장한다
void ls_lnode(struct stat buf)
{
  printf("%d  ", (unsigned int)buf.st_ino);
}

//파일의 형식과 접근 권한을 저장한다
void ls_Mode(struct stat buf)
{
  printf("%o  ", (unsigned long)buf.st_mode);
}

//파일의 사이즈
void ls_FSize(struct stat buf)
{
  printf("%d  ", buf.st_size);
}

// ./myls -l 과 ./myls -i
void ls_option(struct stat buf, char* option)
{
  // ./myls -l => 형식과 접근권한, inode번호, 파일 사이즈 출력
  if(strcmp(option, "-l") == 0)
  {
    ls_Mode(buf);
    ls_lnode(buf);
    ls_FSize(buf);
  }

  // ./myls -i =>ls의 기능 + inode 번호 출력
  else if(strcmp(option, "-i")==0)
  {
    ls_lnode(buf);
  }
}

// 리눅스 커널에 존재하는 파일과 디렉터리의 정보를 보여준다.
// ls -l,  ls -a,  ls -i 의 옵션을 통해 
// 해당 디렉터리의 내용과 출력값을 관리하는 main 이다.
int main(int argc, char*argv[])
{
  char* cwd=(char*)malloc(sizeof(char)*1024);
  memset(cwd, 0, 1024);

  DIR*dir = NULL;
  struct dirent*entry;
  struct stat buf;

  getcwd(cwd, 1024);

  if((dir = opendir(cwd)) == NULL)
  {
    printf("opendir() error\n");
    exit(1);
  }
  while((entry = readdir(dir)) != NULL)
  {
    lstat(entry->d_name, &buf);
    if(S_ISREG(buf.st_mode))
      printf("FILE  ");
    else if(S_ISDIR(buf.st_mode))
      printf("DIR  ");
    else
      printf("???  ");
    if(argc > 1)
      ls_option(buf, argv[1]);
    printf("%s  \n", entry->d_name);
  }

  free(cwd);
  closedir(dir);

  return 0;

}


//참조 사이트들
//https://12bme.tistory.com/215
//https://go-it.tistory.com/4
//https://m.blog.naver.com/PostView.nhn?blogId=neakoo35&logNo=30125127381&proxyReferer=https:%2F%2Fwww.google.com%2F
//http://pds3.egloos.com/pds/200707/31/95/myls.c
