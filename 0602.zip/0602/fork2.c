#include <stdio.h>
#include <unistd.h>
int main()
{
  int pid;

  pid = fork();
  if(pid == 0) //pid는 2개의 값이 리턴 됨
  {
    printf("[Child] : Hello, world pid = %d\n", getpid());
  }
  else
  {
    printf("[Parent] : Hello, world pid = %d\n", getpid());
  }

}

//printf문장을 많이 넣으면 parent와 child가
//번갈아가면서 출력된다 
//부모, 자식 프로세스는 병행적으로 실행된다
