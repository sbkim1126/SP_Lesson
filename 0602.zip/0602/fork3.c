#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/* 부모 프로세스가 두 개의 자식 프로세스를 생성한다. */
int main() 
{
   int pid1, pid2;

   pid1 = fork();
   if (pid1 == 0) {
      printf("[Child 1] : Hello, world ! pid=%d\n",getpid());
      exit(0);
   }

   pid2 = fork();
   if (pid2 == 0) {
      printf("[Child 2] : Hello, world ! pid=%d\n",getpid());
      exit(0);
   }
}
/*printf 문장의 개수를 늘리고 pid1 pid2사이에 프린트문 여러개를
추가하고 마지막 pid2가 끝난 후 print문을 여러개 넣어서 출력해보면
마찬가지로 부모와 child1이 병행적으로 하고
그다음 parent는 그대로고 child2가 병행적으로 실행된다
하나의 프로세스에서 다른 프로세스, 다른 명령을
자기자신을 똑같이 복사해서 주기억장치에 저장하고
병행적으로 실행한다*/
