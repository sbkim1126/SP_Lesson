#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/* 자식 프로세스를 생성하여 echo 명령어를 실행한다. */
int main( ) 
{	
     printf("부모 프로세스 시작\n");
	 if (fork( ) == 0) {
	      execl("/bin/echo", "echo", "hello", NULL);
	      fprintf(stderr,"첫 번째 실패");    
          exit(1);
	 }
     printf("부모 프로세스 끝\n");
}

/*결과는 부모프로세스 시작, 끝 다음 hello만 출력됨
부모가 실행되고 -> 자식이 실행되어야 하는데
그때 echo hello가 실행된다
즉, 자식프로그램을 아예 다른 프로그램으로 대치한 것
하나의 프로세스가 존재하고
이 프로세스가 메모리에 계속 동작하면서
다른 프로그램을 실행할 수 있다는 것
쉘이란 프로그램이 우리가 입력하는 명령어를 실행시키는 원리*/
