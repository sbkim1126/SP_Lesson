#include <unistd.h> 
//링크 명령어(ln) 구현, 파일 2개를 받음
int main(int argc, char *argv[ ]) 
{ 
  if (link(argv[1], argv[2]) == -1) 
  { 
    exit(1); 
  } 

  exit(0); 
}
