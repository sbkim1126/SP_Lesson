#include <sys/types.h> 
#include <sys/stat.h> 
#include <sys/time.h> 
#include <utime.h>       
#include <stdio.h>      
#include <stdlib.h> 

int main(int argc, char *argv[]) 
{ 
  struct stat buf;        // 파일 상태 저장을 위한 변수 
  struct utimbuf time; 
  
  if (argc < 3) 
  {//실행파일명 파일1 파일2 
    fprintf(stderr, "사용법: cptime file1 file2\n"); 

    exit(1); 
  } //파일 상세정보 가져와
  if (stat(argv[1], &buf) <0) { // 상태 가져오기 
    perror("stat()"); 
    
    exit(-1); 
  } 
//구조체의 각각의 member에 할당
  time.actime = buf.st_atime; 
  time.modtime = buf.st_mtime; 
//접근 수정 시간을 변경
  if (utime(argv[2], &time))   // 접근, 수정 시간 복사 
    perror("utime"); 
  else exit(0); 

} 
