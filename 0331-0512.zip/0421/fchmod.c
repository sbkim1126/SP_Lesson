#include <sys/types.h> 
#include <sys/stat.h> 
#include <stdio.h> 
#include <stdlib.h> 

//inode에 있는 data를 가져와서 처리하고있다 
/* 파일 사용권한을 변경한다. */ 
int main(int argc, char *argv[]) 
{ 
  long strtol( ); 
  int newmode; 
  //실행파일 뒤에 8진수를 기술해야 이 파일이 실행됨
  
  newmode = (int) strtol(argv[1], (char **) NULL, 8); 

//argv[2] 파일에 대해서 chmod함수를 적용시키는 것
  if (chmod(argv[2], newmode) == -1) 
  { 
    perror(argv[2]); 

    exit(1); 
  } 
  exit(0); 
}
