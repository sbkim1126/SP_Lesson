#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <stdlib.h>
#include <unistd.h>

//ls -i 하면 i 노드 검색가능
/*파일 타입을 검사한다*/
int main(int argc, char *argv[])
//argc : 인자를 몇 가지를 주느냐 개수를 잡는 것 argument count
//argv[] : 문자열 이 이 배열이다
//void 하면 아래의 argc를 쓸 수 없다
{
  int i;
  struct stat buf;

  for(i=1; i < argc; i++) //여러 개의 파일을 검사한다는 뜻
  {
    printf("%s: ", argv[i]); //각각을 출력
    //각각의 argv를 buf에 넣었다
    if(lstat(argv[i], &buf) < 0)
    {//그 파일이 어떤 파일인지 검색
      perror("lstat()");
      continue;
    }
  printf(" inode Number : %ld.  ", buf.st_ino);

  if (S_ISREG(buf.st_mode)) 
    printf("%s \n", "일반 파일"); 
  if (S_ISDIR(buf.st_mode)) 
    printf("%s \n", "디렉터리"); 
  if (S_ISCHR(buf.st_mode)) 
    printf("%s \n", "문자 장치 파일"); 
  if (S_ISBLK(buf.st_mode)) 
    printf("%s \n", "블록 장치 파일"); 
  if (S_ISFIFO(buf.st_mode)) 
    printf("%s \n", "FIFO 파일"); 
  if (S_ISLNK(buf.st_mode)) 
    printf("%s \n", "심볼릭 링크"); 
  if (S_ISSOCK(buf.st_mode)) 
    printf("%s \n", "소켓");
  } 
  exit(0);
}
