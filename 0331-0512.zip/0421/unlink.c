#include <unistd.h> 
#include <stdio.h>
#include <stdlib.h>

//링크를 해제하는 것
int main(int argc, char *argv[ ]) 
{ 
  int unlink( ); 

  if (unlink(argv[1]) == -1) 
  { 
    perror(argv[1]); 

    exit(1); 
  } 

  exit(0); 

}

