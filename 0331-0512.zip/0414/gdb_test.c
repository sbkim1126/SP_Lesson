#include <stdio.h>
#include <stdlib.h>
#define MAX 256

int main(void)
{
   int n;
   char* buf = (char*)malloc(sizeof(char)*MAX+1);
//동적으로 메모리 필요해서 malloc, sizeof로 사이즈 얼만큼 필요한지, 어떤데이터가 들어가는지 타입지정 char*
   FILE *fp;

   if((fp=fopen("/etc/hosts", "r"))==NULL){ //파일을 읽기전용으로 연다.
      printf("can not open file\n");//null이면 error문장 출력
      exit(1);
   }
   n = fread(buf, 1, MAX, fp); //fp파일에서 1부터 max(256) 만큼 읽어서 buf배열에 넣습니다
   buf[n]='\0';//아래 %s문자열이 있잖아, 이 문자열의 제일 끝을 표기하기 위해서는 아스키코드 '0'이 들어가야한다 => 문자열의 끝을 인식, null추가한다 생각
   printf("buf : %s\n", buf);//buf는 주소, %s에 buf주소 전달, 주소에 가서 문자 하나씩 출력합니다 null문자를 만날 때 까지.
   fclose(fp);
   return 0;
}

//암기 추천
