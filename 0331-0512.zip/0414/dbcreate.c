#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include "student.h"

/* 학생 정보를 입력받아 데이터베이스 파일에 저장한다. */
int main(int argc, char *argv[])
{
    int fd;
    struct student rec;

    if (argc < 2) {
// => 여기서 기술한 argv 1이
        fprintf(stderr,  "사용법 : %s file\n", argv[0]);
        exit(1);
    }
// => 여기서 쓰여짐 
    if ((fd = open(argv[1],O_WRONLY |O_CREAT, 0640))==-1) {
//0640 나만 읽고쓰기 가능하고 그룹은 읽기 others는 아무것도 못함
        perror(argv[1]);
        exit(2);
    }
//숫자는 크기, -는 정렬 위치 %-이런거 잘 알아두기
    printf("%-9s %-8s %-4s", "학번",  "이름",  "점수"); 
//학번 이름 점수를 입력받으면 계속 이 명령을 수행하라는 것
    while (scanf("%d %s %d", &rec.id, rec.name, &rec.score) ==  3) {
//seek_set 제일 처음으로 가라, start_id가 1401001이야
//id가 int야, 제일처음은 seek_set앞에 있는 애들이 0이어야해
//그러면 0을 만들려면 학번이 1401001이면 되는거야 그러면 파일의 맨 처음으로 가지
//lseek => 파일의 위치포인터 지정
        lseek(fd, (rec.id - START_ID) * sizeof(rec), SEEK_SET);
//sizeof 크기 만큼 rec를 쓰세요
        write(fd, &rec, sizeof(rec) );
    }

    close(fd);
    exit(0);
}
