#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
//b_counter라는 파일을 만들어줌 버퍼만큼 1 2 3 만 적혀있는 내용으로
#define BLOCK_SIZE 16
int main()
{
    int fd;
    int i;
    char buf[BLOCK_SIZE];
    if ((fd = open("b_counter", O_CREAT|O_WRONLY)) == -1)
    {
        perror("file open error : ");
        exit(0);
    }
    for(i = 1; i < 4; i++)
    {
        memset(buf, 0x00, BLOCK_SIZE);
        sprintf(buf,"%d", i);
        write(fd, buf, BLOCK_SIZE);
    }    
    close(fd);
}
