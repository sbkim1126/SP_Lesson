#include <sys/types.h> 
#include <sys/stat.h> 
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>

/* ?붾젆?곕━ ?댁쓽 ?뚯씪 ?대쫫?ㅼ쓣 由ъ뒪?명븳?? */
int main(int argc, char **argv) 
{
    DIR *dp;
    char *dir;
    struct dirent *d;
    struct stat st;
    char path[BUFSIZ+1];

    if (argc == 1) 
        dir = "."; 	// ?꾩옱 ?붾젆?곕━瑜???곸쑝濡?
    else dir = argv[1];

    if ((dp = opendir(dir)) == NULL) {  // ?붾젆?곕━ ?닿린 
        perror(dir);
        exit(1);
    }

    while ((d = readdir(dp)) != NULL)  // ?붾젆?곕━ ?댁쓽 媛??뷀듃由ъ뿉 ???
        printf("%s \n", d->d_name);    // ?뚯씪 ?대쫫 ?꾨┛??

    closedir(dp);
    exit(0);
}
