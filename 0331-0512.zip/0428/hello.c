#include <stdio.h>

int main()
{//\n이 캐리지 라인 리턴임
  printf("Hello C world!!\n");

  return 0;
}
