#include <stdio.h>

int main()
{//\n이 캐리지 라인 리턴
  printf("Hello C worldl!!\n");

  return 0;
}
