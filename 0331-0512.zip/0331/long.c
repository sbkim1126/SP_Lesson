#include <stdio.h>
#include <string.h>
#define MAXLINE 100
void copy(char from[], char to[]);
char *mygets(char *buf, size_t size);
/*size_t 데이터 타입 : 메모리영역의 최대 크기의 데이터를 표현하는 타입
unsigned int이며 음수가 필요없는 것을 나타낼 때 쓰는 것
문자열이나 메모리의 사이즈를 나타낼 때 씀*/
char line[MAXLINE]; //입력 줄
char longest[MAXLINE];// 가장 긴 줄
//어느 함수에서나 다 쓸 거니까 밖에 정의 해둠

/*입력 줄 가운데 가장 긴 줄 프린트*/
int main()
{
  int len;
  int max;
  max = 0;

  //gets안돼서 mygets하래 밑에 추가함
  while(mygets(line, sizeof(line)) != NULL) //입력받고 null이 아니면
  {
    len = strlen(line); //라인의 길이 구하고
    if(len > max)// 길이를 숫자로 바꿔서 max랑 비교
    {
      max = len; //len에 저장해놓고
      copy(line, longest); //copy함
    }
  } //라인이 null이 될 때 까지 반복
  if(max > 0) //입력 줄이 있었다면
 //max가 0보다 크면 longest 출력하세요
    printf("%s", longest); 

  return 0;
}

/*copy : from 을 to에 복사; 
         to가 충분히 크다고 가정*/

//배열을 copy하는 함수
void copy(char from[], char to[])
{
  int i;
  i=0;

  while((to[i] = from[i]) != '\0')
    ++i;
}

char *mygets(char *buf, size_t size)
{
  if(buf != NULL && size > 0)
  {
    if(fgets(buf, size, stdin))
    {
      buf[strcspn(buf, "\n")] = '\0';
      return buf;
    }
  *buf = '\0'; /*clear buffer at end of file*/
  }
  return NULL;
}
