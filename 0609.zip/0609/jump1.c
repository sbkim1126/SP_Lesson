#include <stdio.h>
#include <stdlib.h>
#include <setjmp.h>

void  p1(), p2();
jmp_buf env;

int main() 
{
    if (setjmp(env) != 0) {
	printf("오류로 인해 복귀\n");
	exit(0);
    } 
    else printf("처음 통과\n");

    p1(); 
} 

void  p1()
{ 
    p2();
}

void p2() 
{
    int error;
//longjmp로 점프하면 setjmp로 감 
//setjmp의 if문을 실행하게 되는거
//처음통과 -> 오류 -> 점프해서 오류로 인해 복귀 로 감
//error는 0이 아니니까 메시지 출력 
    error = 1;
    if (error) {
        printf("오류\n");
        longjmp(env, 1);
    }
}

