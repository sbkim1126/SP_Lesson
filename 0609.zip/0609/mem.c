#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void main()
{
    char str[32]="Do you like Linux?";
    char *ptr,*p;

    ptr = (char *) malloc(32);
//memcpy 복사한 것 
    memcpy(ptr, str, strlen(str));  
    puts(ptr);
//하나만 l로 바꿈 12번째에 있는 것을 ㅇㅇ 
    memset(ptr+12,'l',1);
    puts(ptr);
//pdf 28페이지에 대한 예제 함수 
    p = (char *) memchr(ptr,'l',18);
    puts(p);
    memmove(str+12,str+7,10); 
    puts(str);
}
