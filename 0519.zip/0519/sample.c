#include <stdio.h>

int main()
{
  printf("Hello c World\n");

  return 3;
}

//main은 shell이 처리 main함수가 종료 할 때 return 할 때 그 value를
//운영체제 shell에 줌
//그걸 볼 수 있는게 echo $?
