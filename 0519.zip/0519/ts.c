#include <stdio.h>
//#include <termios.h>
//#include <unistd.h>

int main()
{
  char a, b;

  printf("대문자 입력 : ");
  scanf(" %c", &a);
  //getchar(); => 하나의 문자를 입력, 입력 버퍼에있는 엔터 값이 getchar에 의해 처리됨
  //fflush(stdin); => 출력버퍼만 지움
  //tcflush();

  //scanf("%c*c",c); => 입력은 받지만 저장은 안함, 비어있는 \n을 날린다
  //scnaf(" %c", &a); => 앞에 공백을 추가하면 white space를 구분자로 인식

  printf("소문자 입력 : ");
  scanf(" %c", &b);

  printf("입력한 %c의 소문자는 %c입니다. \n", a, a+32);

  printf("입력한 %c의 대문자는 %c입니다. \n", b, b-32);

  return 0;
}

//https://plustag.tistory.com/1
