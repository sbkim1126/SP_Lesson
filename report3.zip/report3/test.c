#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
int main_menu_list();
void create_menu();
void query_menu();
int query_menu_list();
void query_menu_func();
void update_menu();
int update_menu_list();
void update_menu_func();
int fd;

struct chicken {
    char brand[28];
    char name[28];
    int score;
};

int main(int argc, char* argv[]) {
    int c;
    if (argc < 2) {
        fprintf(stderr, "사용법 : %s file\n", argv[0]);
        exit(1);
    }
    if ((fd = open(argv[1], O_RDWR | O_CREAT, 0640)) == -1) {
        perror(argv[1]);
        exit(2);
    }
    while (c = main_menu_list()) {
        switch (c) {
        case 1:
            create_menu();
            break;
        case 2:
            query_menu();
            break;
        case 3:
            update_menu();
            break;
        default:
            printf("다시 입력 해주세요.\n");
            printf("계속하려면 엔터를 누르세요.");
            getchar();
            break;
        }
    }
    close(fd);
    return 0;
}


int main_menu_list() {
    int select;
    system("clear");
    printf("치킨치킨\n\n");
    printf("0. 종료\n");
    printf("1. 생성\n");
    printf("2. 질의\n");
    printf("3. 갱신\n");
    printf("원하는 번호를 입력해주세요 : ");
    if ((select = getchar()) == '\n')
        return 4;
    getchar();
    return select - '0';
}

void create_menu() {
    int select;
    struct chicken rec;
    system("clear");
    printf("치킨 생성\n");
    while (1) {
        printf("치킨 브랜드, 대표 치킨, 평점(5점만점)\n");
        printf("문자열 하나에 띄어쓰기를 하지 마세요.\n>> ");
        if (scanf("%s %s %d", rec.brand, rec.name, &rec.score) != 3) break;
        getchar();
        lseek(fd, 0L, SEEK_END);
        write(fd, &rec, sizeof(rec));
        printf("계속 하려면 Y 아니면 아무 키나 누르세요>>");
        char check = getchar();
        if (check == '\n')
            break;
        if (check != 'Y') {
            getchar();
            break;
        }
    }
}

void query_menu() {
    int c;
    struct chicken rec;
    while (c = query_menu_list()) {
        int count = 0;
        switch (c) {
        case 1:
        case 2:
        case 3:
        case 4:
            query_menu_func(c);
            break;
        default:
            printf("다시 입력해주세요.\n");
            printf("계속하려면 엔터를 누르세요.");
            getchar();
            break;
        }
    }
}  

int query_menu_list() {
    int select;
    system("clear");
    printf("치킨 질의\n\n");
    printf("0. 뒤로가기\n");
    printf("1. 모두보기\n");
    printf("2. 치킨 브랜드명으로 검색\n");
    printf("3. 치킨 상품명으로 검색\n");
    printf("4. 평점으로 검색\n");
    printf("원하는 번호를 입력해주세요 : ");
    if ((select = getchar()) == '\n')
        return 0;
    getchar();
    return select - '0';
}

void query_menu_func(int select) {
    struct chicken rec;
    int count = 0;
    if (select == 1) {
        lseek(fd, 0L, SEEK_SET);
        while (read(fd, &rec, sizeof(rec)) > 0)
            printf("%d. %s %s %d\n", ++count, rec.brand, rec.name, rec.score);
    }else if (select == 4) {
        int query;
        printf("알고 싶은 평점 입력 : ");
        scanf("%d", &query);
        getchar();
        lseek(fd, 0L, SEEK_SET);
        while (read(fd, &rec, sizeof(rec)) > 0)
            if(rec.score == query)
                printf("%d. %s %s %d\n", ++count, rec.brand, rec.name, rec.score);
        if (count == 0) printf("평점이 %d인 정보는 없습니다.\n",query);
    }
    else {
        char query[28];
        if (select == 2) {
            printf("알고 싶은 치킨 브랜드 입력 : ");
            scanf("%s", query);
            getchar();
            lseek(fd, 0L, SEEK_SET);
            while (read(fd, &rec, sizeof(rec)) > 0)
                if (!strcmp(rec.brand,query))
                    printf("%d. %s %s %d\n", ++count, rec.brand, rec.name, rec.score);
            if (count == 0) printf("치킨 브랜드가 %s인 정보는 없습니다.\n",query);
        }else {
            printf("알고 싶은 치킨 상품명 입력 : ");
            scanf("%s", query);
            getchar();
            lseek(fd, 0L, SEEK_SET);
            while (read(fd, &rec, sizeof(rec)) > 0)
                if (!strcmp(rec.name, query))
                    printf("%d. %s %s %d\n", ++count, rec.brand, rec.name, rec.score);
            if (count == 0) printf("상품명이 %s인 정보는 없습니다.\n", query);
        }
    }
    printf("계속하려면 엔터를 누르세요.");
    getchar();
}

void update_menu()
{
  int c;
  struct chicken rec;
  while(c = update_menu_list())
  {
    int count = 0;
    switch(c)
    {
      case 1:
      case 2:
        update_menu_func(c);
        break;
      default:
        printf("메뉴값을 정확히 입력해주세요.\n");
        printf("계속하려면 엔터를 누르세요.");
        getchar();                                                                      break;
    }
  }
}

int update_menu_list()
{
  int select;
  system("clear");
  printf("치킨 평점 갱신\n\n");
  printf("0. 뒤로가기\n");
  printf("1. 모두보기\n");
  printf("2. 평점 갱신하기\n");
  printf("원하는 번호를 입력해주세요 : ");
  if((select = getchar()) == '\n')
    return 0;
  getchar();
  return select - '0';
}


void update_menu_func(int select)
{
  struct chicken rec;
  int count = 0;
  if (select == 1)
  {
    lseek(fd, 0L, SEEK_SET);
    while(read(fd, &rec, sizeof(rec)) > 0)
      printf("%d. %s %s %d\n", ++count, rec.brand, rec.name, rec.score);
  }
  else if (select == 2)
  {
    int update;
    printf("알고 싶은 평점 입력 : ");
    scanf("%d", &update);
    getchar();
    lseek(fd, 0L, SEEK_SET);
    while(read(fd, &rec, sizeof(rec)) > 0)
    {
      printf("%s %s %d\n", rec.brand, rec.name, rec.score);
      printf("새로운 평점을 입력해주세요 : ");
      scanf("%d", &rec.score);
      lseek(fd, -sizeof(rec), SEEK_CUR);
      write(fd, &rec, sizeof(rec));
    }
    if(count == 0) printf("평점이 %d인 정보는 없습니다.\n", update);
  }
  printf("계속하려면 엔터를 누르세요.");
  getchar();
}
